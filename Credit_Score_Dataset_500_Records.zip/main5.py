from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np

app = FastAPI(
    title="AI Banking Analytics System",
    description="Banking Fraud Detection & Customer Analytics API",
    version="1.0"
)

# ===========================
# Load Models
# ===========================

credit_model = joblib.load("credit_score_model.pkl")

loan_model = joblib.load("loan_default_model.pkl")

fraud_model = joblib.load("fraud_detection_model.pkl")

customer_model = joblib.load("customer_recommendation_model.pkl")
# ===========================
# Credit Score
# ===========================

class CreditInput(BaseModel):

    Age: int
    Gender: int
    Annual_Income: int
    Employment_Years: int
    Monthly_Income: int
    Existing_Loan: int
    EMI: int
    Credit_Card_Utilization: int
    Missed_Payments: int
    Savings: int
    Loan_History: int
    # ===========================
# Loan Default
# ===========================

class LoanInput(BaseModel):

    Age: int
    Income: int
    Loan_Amount: int
    EMI: int
    Employment_Years: int
    Credit_Score: int
    Previous_Defaults: int
    Debt_to_Income: int
    # ===========================
# Fraud Detection
# ===========================

class FraudInput(BaseModel):

    Amount: int
    Transaction_Type: int
    Location: int
    Device: int
    Hour: int
    Merchant_Category: int
    International: int
    # ===========================
# Customer Recommendation
# ===========================

class CustomerInput(BaseModel):

    Age: int
    Income: int
    Savings: int
    Credit_Score: int
    Loan_Amount: int
    Spending_Score: int
    # ===========================
# Home API
# ===========================

@app.get("/")
def home():

    return {
        "message": "AI Banking Analytics System API is Running Successfully"
    }


# ===========================
# Credit Score Prediction
# ===========================

@app.post("/predict_credit_score")
def predict_credit(data: CreditInput):

    input_data = np.array([[
        data.Age,
        data.Gender,
        data.Annual_Income,
        data.Employment_Years,
        data.Monthly_Income,
        data.Existing_Loan,
        data.EMI,
        data.Credit_Card_Utilization,
        data.Missed_Payments,
        data.Savings,
        data.Loan_History
    ]])

    prediction = credit_model.predict(input_data)

    return {
        "Predicted_Credit_Score": float(prediction[0])
    }


# ===========================
# Loan Default Prediction
# ===========================

@app.post("/predict_loan_default")
def predict_loan(data: LoanInput):

    input_data = np.array([[
        data.Age,
        data.Income,
        data.Loan_Amount,
        data.EMI,
        data.Employment_Years,
        data.Credit_Score,
        data.Previous_Defaults,
        data.Debt_to_Income
    ]])

    prediction = loan_model.predict(input_data)

    if prediction[0] == 1:
        result = "Loan Default"
    else:
        result = "No Loan Default"

    return {
        "Prediction": result
    }
# ===========================
# Fraud Detection Prediction
# ===========================

@app.post("/predict_fraud")
def predict_fraud(data: FraudInput):

    input_data = np.array([[
        data.Amount,
        data.Transaction_Type,
        data.Location,
        data.Device,
        data.Hour,
        data.Merchant_Category,
        data.International
    ]])

    prediction = fraud_model.predict(input_data)

    if prediction[0] == 1:
        result = "Fraud Transaction"
    else:
        result = "Genuine Transaction"

    return {
        "Prediction": result
    }


# ===========================
# Customer Recommendation
# ===========================

@app.post("/recommend_customer")
def recommend_customer(data: CustomerInput):

    input_data = np.array([[
        data.Age,
        data.Income,
        data.Savings,
        data.Credit_Score,
        data.Loan_Amount,
        data.Spending_Score
    ]])

    prediction = customer_model.predict(input_data)

    if prediction[0] == 0:
        segment = "Gold"
    elif prediction[0] == 1:
        segment = "Platinum"
    else:
        segment = "Silver"

    return {
        "Recommended_Customer_Segment": segment
    }


# ===========================
# Run FastAPI
# ===========================

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host="127.0.0.1",
        port=8000,
        reload=True
    )