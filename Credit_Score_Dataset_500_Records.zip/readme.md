# SmartBank AI Analytics

## Features
- Credit Score Prediction
- Loan Default Detection
- Fraud Detection
- Customer Segmentation


## Tech Stack
- Backend: FastAPI
- Database: PostgreSQL
- ML: Scikit-learn, Joblib

## Installation
1. Install dependencies: `pip install -r requirements.txt`
2. Run server: `uvicorn main25:app --reload`