from pydantic import BaseModel
from typing import Optional

# Credit Prediction Schemas
class CreditInput(BaseModel):
    Age: int
    Gender: int
    Annual_Income: int
    Employment_Years: int
    Monthly_Income: int
    Existing_Loan: int
    EMI: int
    Credit_Card_Utilization: int
    Missed_Payments: int
    Savings: int
    Loan_History: int

# Loan Prediction Schemas
class LoanInput(BaseModel):
    Age: int
    Income: int
    Loan_Amount: int
    EMI: int
    Employment_Years: int
    Credit_Score: int
    Previous_Defaults: int
    Debt_to_Income: int

# Fraud Detection Schemas
class FraudInput(BaseModel):
    Amount: int
    Transaction_Type: int
    Location: int
    Device: int
    Hour: int
    Merchant_Category: int
    International: int

# Customer Recommendation Schemas
class CustomerInput(BaseModel):
    Age: int
    Income: int
    Savings: int
    Credit_Score: int
    Loan_Amount: int
    Spending_Score: int