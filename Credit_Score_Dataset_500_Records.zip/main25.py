from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np
from sqlalchemy import create_engine, Column, Integer, Float, String, TIMESTAMP
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.sql import func
from fastapi.middleware.cors import CORSMiddleware
from schemas import CreditInput, LoanInput, FraudInput, CustomerInput

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==========================================
# PostgreSQL Database Connection
# ==========================================
DATABASE_URL = "postgresql://postgres:admin@host.docker.internal:5432/banking1_db"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# ==========================================
# Load Models
# ==========================================
credit_model = joblib.load("credit_score_model.pkl")
loan_model = joblib.load("loan_default_model.pkl")
fraud_model = joblib.load("fraud_detection_model.pkl")
customer_model = joblib.load("customer_recommendation_model.pkl")

# ==========================================
# Pydantic Input Models
# ==========================================
class CreditInput(BaseModel):
    Age: int; Gender: int; Annual_Income: int; Employment_Years: int; Monthly_Income: int
    Existing_Loan: int; EMI: int; Credit_Card_Utilization: int; Missed_Payments: int
    Savings: int; Loan_History: int

class LoanInput(BaseModel):
    Age: int; Income: int; Loan_Amount: int; EMI: int; Employment_Years: int
    Credit_Score: int; Previous_Defaults: int; Debt_to_Income: int

class FraudInput(BaseModel):
    Amount: int; Transaction_Type: int; Location: int; Device: int
    Hour: int; Merchant_Category: int; International: int

class CustomerInput(BaseModel):
    Age: int; Income: int; Savings: int; Credit_Score: int; Loan_Amount: int; Spending_Score: int

# ==========================================
# Database Models
# ==========================================
class CreditPrediction(Base):
    __tablename__ = "credit_predictions"
    id = Column(Integer, primary_key=True, index=True)
    age = Column(Integer); gender = Column(Integer); annual_income = Column(Integer)
    employment_years = Column(Integer); monthly_income = Column(Integer); existing_loan = Column(Integer)
    emi = Column(Integer); credit_card_utilization = Column(Integer); missed_payments = Column(Integer)
    savings = Column(Integer); loan_history = Column(Integer); predicted_credit_score = Column(Float)
    created_at = Column(TIMESTAMP, server_default=func.now())

class LoanPrediction(Base):
    __tablename__ = "loan_predictions"
    id = Column(Integer, primary_key=True, index=True)
    age = Column(Integer); income = Column(Integer); loan_amount = Column(Integer)
    emi = Column(Integer); employment_years = Column(Integer); credit_score = Column(Integer)
    previous_defaults = Column(Integer); debt_to_income = Column(Integer); prediction = Column(String(50))
    created_at = Column(TIMESTAMP, server_default=func.now())

class FraudPrediction(Base):
    __tablename__ = "fraud_predictions"
    id = Column(Integer, primary_key=True, index=True)
    amount = Column(Integer); transaction_type = Column(Integer); location = Column(Integer)
    device = Column(Integer); hour = Column(Integer); merchant_category = Column(Integer)
    international = Column(Integer); prediction = Column(String(50))
    created_at = Column(TIMESTAMP, server_default=func.now())

class CustomerPrediction(Base):
    __tablename__ = "customer_predictions"
    id = Column(Integer, primary_key=True, index=True)
    age = Column(Integer); income = Column(Integer); savings = Column(Integer)
    credit_score = Column(Integer); loan_amount = Column(Integer); spending_score = Column(Integer)
    recommended_segment = Column(String(50))
    created_at = Column(TIMESTAMP, server_default=func.now())

Base.metadata.create_all(bind=engine)

# ==========================================
# Prediction Endpoints
# ==========================================

@app.post("/predict_credit_score")
def predict_credit(data: CreditInput):
    input_data = np.array([[data.Age, data.Gender, data.Annual_Income, data.Employment_Years, data.Monthly_Income, data.Existing_Loan, data.EMI, data.Credit_Card_Utilization, data.Missed_Payments, data.Savings, data.Loan_History]])
    prediction = credit_model.predict(input_data)
    db = SessionLocal()
    new_prediction = CreditPrediction(age=data.Age, gender=data.Gender, annual_income=data.Annual_Income, employment_years=data.Employment_Years, monthly_income=data.Monthly_Income, existing_loan=data.Existing_Loan, emi=data.EMI, credit_card_utilization=data.Credit_Card_Utilization, missed_payments=data.Missed_Payments, savings=data.Savings, loan_history=data.Loan_History, predicted_credit_score=float(prediction[0]))
    db.add(new_prediction); db.commit(); db.refresh(new_prediction); db.close()
    return {"Predicted_Credit_Score": float(prediction[0]), "Message": "Saved Successfully"}

@app.post("/predict_loan_default")
def predict_loan(data: LoanInput):
    input_data = np.array([[data.Age, data.Income, data.Loan_Amount, data.EMI, data.Employment_Years, data.Credit_Score, data.Previous_Defaults, data.Debt_to_Income]])
    prediction = loan_model.predict(input_data)
    result = "Loan Default" if prediction[0] == 1 else "No Loan Default"
    db = SessionLocal()
    new_prediction = LoanPrediction(age=data.Age, income=data.Income, loan_amount=data.Loan_Amount, emi=data.EMI, employment_years=data.Employment_Years, credit_score=data.Credit_Score, previous_defaults=data.Previous_Defaults, debt_to_income=data.Debt_to_Income, prediction=result)
    db.add(new_prediction); db.commit(); db.refresh(new_prediction); db.close()
    return {"Prediction": result, "Message": "Saved Successfully"}

@app.post("/predict_fraud")
def predict_fraud(data: FraudInput):
    input_data = np.array([[data.Amount, data.Transaction_Type, data.Location, data.Device, data.Hour, data.Merchant_Category, data.International]])
    prediction = fraud_model.predict(input_data)
    result = "Fraud Transaction" if prediction[0] == 1 else "Genuine Transaction"
    db = SessionLocal()
    new_prediction = FraudPrediction(amount=data.Amount, transaction_type=data.Transaction_Type, location=data.Location, device=data.Device, hour=data.Hour, merchant_category=data.Merchant_Category, international=data.International, prediction=result)
    db.add(new_prediction); db.commit(); db.refresh(new_prediction); db.close()
    return {"Prediction": result, "Message": "Saved Successfully"}

@app.post("/recommend_customer")
def recommend_customer(data: CustomerInput):
    input_data = np.array([[data.Age, data.Income, data.Savings, data.Credit_Score, data.Loan_Amount, data.Spending_Score]])
    prediction = customer_model.predict(input_data)
    result = str(prediction[0])
    db = SessionLocal()
    new_prediction = CustomerPrediction(age=data.Age, income=data.Income, savings=data.Savings, credit_score=data.Credit_Score, loan_amount=data.Loan_Amount, spending_score=data.Spending_Score, recommended_segment=result)
    db.add(new_prediction); db.commit(); db.refresh(new_prediction); db.close()
    return {"Recommended_Segment": result, "Message": "Saved Successfully"}

# GET Endpoints for Admin
@app.get("/get_loan_data")
def get_loan():
    db = SessionLocal()
    data = db.query(LoanPrediction).all()
    db.close()
    return data
from crude import delete_loan_prediction, update_loan_prediction

@app.delete("/delete_loan/{loan_id}")
def remove_loan(loan_id: int):
    return delete_loan_prediction(loan_id)

@app.put("/update_loan/{loan_id}")
def update_loan(loan_id: int, new_pred: str):
    return update_loan_prediction(loan_id, new_pred)